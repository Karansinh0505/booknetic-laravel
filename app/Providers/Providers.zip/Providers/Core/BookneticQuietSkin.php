<?php

namespace BookneticApp\Providers\Core;

class BookneticQuietSkin extends \WP_Upgrader_Skin
{

	public function feedback( $string, ...$args )
	{

	}

	public function header()
	{

	}

	public function footer()
	{

	}

}
