<?php

namespace BookneticApp\Providers;

/**
 * @deprecated
 */
class Helper extends Helpers\Helper
{

}